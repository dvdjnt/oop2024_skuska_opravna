package sk.stuba.fei.uim.oop;

public class Main {
    public static void main(String[] args) {
        System.out.println("OOP 2024");
    }
}